package com.example.TigoStarSystem.supervisor.repository;

import com.example.TigoStarSystem.supervisor.dto.ConformacionCuadrillaWebRequest;
import com.example.TigoStarSystem.supervisor.dto.ConformacionCuadrillaWebResponse;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Repository
public class ConformacionCuadrillaWebRepository {
    private static final String SP_LISTAR =
            "EXEC dbo.spx_ObtenerConformacionCuadrillaWeb ?, ?, ?";
    private static final String SP_OBTENER_POR_ID =
            "EXEC dbo.spx_ObtenerConformacionCuadrillaWebPorId ?";
    private static final String SP_CREAR =
            "EXEC dbo.spx_RegistrarConformacionCuadrillaWeb ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?";
    private static final String SP_ACTUALIZAR =
            "EXEC dbo.spx_ActualizarConformacionCuadrillaWeb ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?";
    private static final String SP_ELIMINAR =
            "EXEC dbo.spx_EliminarConformacionCuadrillaWeb ?";
    private static final String SP_TECNICOS =
            "EXEC dbo.spx_ObtenerTecnicosConformacionCuadrillaWeb";
    private static final String SP_TECNICO_DETALLE =
            "EXEC dbo.spx_ObtenerDatosTecnicoConformacionCuadrillaWeb ?";
    private static final String SP_AUXILIARES =
            "EXEC dbo.spx_ObtenerAuxiliaresConformacionCuadrillaWeb";
    private static final String SP_DIGITADORES =
            "EXEC dbo.spx_ObtenerDigitadoresConformacionCuadrillaWeb";
    private static final String SP_SUPERVISORES =
            "EXEC dbo.spx_ObtenerSupervisoresConformacionCuadrillaWeb";
    private static final String SP_ACTIVIDADES =
            "EXEC dbo.spx_ObtenerActividadesConformacionCuadrillaWeb";
    private static final String SP_VEHICULOS =
            "EXEC dbo.spx_ObtenerVehiculosConformacionCuadrillaWeb ?";
    private static final String SP_SUCURSALES =
            "EXEC dbo.spx_ObtenerSucursalesConformacionCuadrillaWeb";

    private final JdbcTemplate centralJdbcTemplate;

    public ConformacionCuadrillaWebRepository(
            @Qualifier("centralJdbcTemplate") JdbcTemplate centralJdbcTemplate) {
        this.centralJdbcTemplate = centralJdbcTemplate;
    }

    public List<ConformacionCuadrillaWebResponse> listar(LocalDate fecha, String sucursal, Integer limite) {
        Object fechaParam = fecha == null ? null : Date.valueOf(fecha);
        String sucursalParam = (sucursal == null || sucursal.trim().isEmpty()) ? null : sucursal.trim();
        List<Map<String, Object>> rows = centralJdbcTemplate.queryForList(
                SP_LISTAR,
                fechaParam,
                sucursalParam,
                limite
        );
        return mapRows(rows);
    }

    public ConformacionCuadrillaWebResponse obtenerPorId(Long id) {
        List<Map<String, Object>> rows = centralJdbcTemplate.queryForList(SP_OBTENER_POR_ID, id);
        if (rows.isEmpty()) {
            return null;
        }
        return mapRow(rows.get(0));
    }

    public Long crear(ConformacionCuadrillaWebRequest request) {
        List<Map<String, Object>> rows = centralJdbcTemplate.queryForList(
                SP_CREAR,
                request.getFecha() == null ? null : Date.valueOf(request.getFecha()),
                request.getEstado(),
                request.getActividad(),
                request.getIdTecnico(),
                request.getCuentaSf(),
                request.getSalesforce(),
                request.getHabilidad(),
                request.getVehiculo(),
                request.getGrupo(),
                request.getAlmacen(),
                request.getGrupoDigitacion(),
                request.getIdUsuarioDigitador(),
                request.getDigitador(),
                request.getTecnico(),
                request.getIdTecnicoAuxiliar(),
                request.getAuxiliar(),
                request.getIdUsuarioSupervisor(),
                request.getSupervisorACargo(),
                request.getSucursal(),
                request.getObservacion(),
                request.getIdUsuarioRegistra()
        );
        if (rows == null || rows.isEmpty()) {
            return null;
        }
        Map<String, Object> row = rows.get(0);
        Object idValue = findValue(
                row,
                "id",
                "id_conformacion_cuadrilla",
                "idconformacioncuadrilla",
                "idregistro"
        );
        if (idValue == null) {
            idValue = firstValue(row);
        }
        return toLong(idValue);
    }

    public int actualizar(Long id, ConformacionCuadrillaWebRequest request) {
        return centralJdbcTemplate.update(
                SP_ACTUALIZAR,
                id,
                request.getFecha() == null ? null : Date.valueOf(request.getFecha()),
                request.getEstado(),
                request.getActividad(),
                request.getIdTecnico(),
                request.getCuentaSf(),
                request.getSalesforce(),
                request.getHabilidad(),
                request.getVehiculo(),
                request.getGrupo(),
                request.getAlmacen(),
                request.getGrupoDigitacion(),
                request.getIdUsuarioDigitador(),
                request.getDigitador(),
                request.getTecnico(),
                request.getIdTecnicoAuxiliar(),
                request.getAuxiliar(),
                request.getIdUsuarioSupervisor(),
                request.getSupervisorACargo(),
                request.getSucursal(),
                request.getObservacion(),
                request.getIdUsuarioRegistra()
        );
    }

    public int eliminar(Long id) {
        return centralJdbcTemplate.update(SP_ELIMINAR, id);
    }

    public List<Map<String, Object>> listarTecnicos() {
        return centralJdbcTemplate.queryForList(SP_TECNICOS);
    }

    public List<Map<String, Object>> obtenerTecnicoDetalle(Integer idTecnico) {
        return centralJdbcTemplate.queryForList(SP_TECNICO_DETALLE, idTecnico);
    }

    public List<Map<String, Object>> listarAuxiliares() {
        return centralJdbcTemplate.queryForList(SP_AUXILIARES);
    }

    public List<Map<String, Object>> listarDigitadores() {
        return centralJdbcTemplate.queryForList(SP_DIGITADORES);
    }

    public List<Map<String, Object>> listarSupervisores() {
        return centralJdbcTemplate.queryForList(SP_SUPERVISORES);
    }

    public List<Map<String, Object>> listarActividades() {
        return centralJdbcTemplate.queryForList(SP_ACTIVIDADES);
    }

    public List<Map<String, Object>> listarVehiculos(String filtro) {
        String filtroParam = (filtro == null || filtro.trim().isEmpty()) ? null : filtro.trim();
        return centralJdbcTemplate.queryForList(SP_VEHICULOS, filtroParam);
    }

    public List<Map<String, Object>> listarSucursales() {
        return centralJdbcTemplate.queryForList(SP_SUCURSALES);
    }

    private List<ConformacionCuadrillaWebResponse> mapRows(List<Map<String, Object>> rows) {
        List<ConformacionCuadrillaWebResponse> result = new ArrayList<>();
        if (rows == null || rows.isEmpty()) {
            return result;
        }
        for (Map<String, Object> row : rows) {
            result.add(mapRow(row));
        }
        return result;
    }

    private ConformacionCuadrillaWebResponse mapRow(Map<String, Object> row) {
        ConformacionCuadrillaWebResponse out = new ConformacionCuadrillaWebResponse();
        out.setId(toLong(findValue(row, "id")));
        out.setFecha(toLocalDate(findValue(row, "fecha")));
        out.setEstado(toString(findValue(row, "estado")));
        out.setActividad(toString(findValue(row, "actividad")));
        out.setIdTecnico(toInteger(findValue(row, "id_tecnico", "idtecnico")));
        out.setCuentaSf(toString(findValue(row, "cuenta_sf", "cuentasf")));
        out.setSalesforce(toString(findValue(row, "salesforce")));
        out.setHabilidad(toString(findValue(row, "habilidad")));
        out.setVehiculo(toString(findValue(row, "vehiculo")));
        out.setGrupo(toString(findValue(row, "grupo")));
        out.setAlmacen(toString(findValue(row, "almacen")));
        out.setGrupoDigitacion(toString(findValue(row, "grupoDigitacion", "grupodigitacion")));
        out.setIdUsuarioDigitador(toInteger(findValue(
                row,
                "idUsuarioDigitador",
                "id_usuario_digitador",
                "idusuariodigitador"
        )));
        out.setDigitador(toString(findValue(row, "digitador")));
        out.setTecnico(toString(findValue(row, "tecnico")));
        out.setIdTecnicoAuxiliar(toInteger(findValue(row, "id_tecnicoAuxiliar", "idtecnicoauxiliar")));
        out.setAuxiliar(toString(findValue(row, "auxiliar")));
        out.setIdUsuarioSupervisor(toInteger(findValue(
                row,
                "idUsuarioSupervisor",
                "id_usuario_supervisor",
                "idusuariosupervisor"
        )));
        out.setSupervisorACargo(toString(findValue(row, "supervisorACargo", "supervisor_a_cargo")));
        out.setSucursal(toString(findValue(row, "sucursal")));
        out.setObservacion(toString(findValue(row, "observacion")));
        out.setIdUsuarioRegistra(toInteger(findValue(
                row,
                "idUsuarioRegistra",
                "id_usuario_registra",
                "idusuarioregistra"
        )));
        out.setFechaRegistro(toLocalDateTime(findValue(row, "fechaRegistro", "fecha_registro")));
        out.setEEliminado(toBoolean(findValue(row, "e_eliminado", "eeliminado")));
        return out;
    }

    private Object findValue(Map<String, Object> row, String... candidates) {
        Map<String, Object> normalized = new HashMap<>();
        for (Map.Entry<String, Object> entry : row.entrySet()) {
            normalized.put(normalize(entry.getKey()), entry.getValue());
        }
        for (String candidate : candidates) {
            String key = normalize(candidate);
            if (normalized.containsKey(key)) {
                return normalized.get(key);
            }
        }
        return null;
    }

    private String normalize(String value) {
        return value == null ? "" : value.replace("_", "").toLowerCase(Locale.ROOT);
    }

    private Object firstValue(Map<String, Object> row) {
        if (row == null || row.isEmpty()) {
            return null;
        }
        return row.values().iterator().next();
    }

    private Integer toInteger(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        try {
            return Integer.parseInt(value.toString().trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private Long toLong(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Number) {
            return ((Number) value).longValue();
        }
        try {
            return Long.parseLong(value.toString().trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private Boolean toBoolean(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue() != 0;
        }
        String text = value.toString().trim().toLowerCase(Locale.ROOT);
        if (text.equals("1") || text.equals("true") || text.equals("si") || text.equals("s")) {
            return true;
        }
        if (text.equals("0") || text.equals("false") || text.equals("no") || text.equals("n")) {
            return false;
        }
        return null;
    }

    private LocalDate toLocalDate(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof LocalDate) {
            return (LocalDate) value;
        }
        if (value instanceof Date) {
            return ((Date) value).toLocalDate();
        }
        if (value instanceof Timestamp) {
            return ((Timestamp) value).toLocalDateTime().toLocalDate();
        }
        if (value instanceof LocalDateTime) {
            return ((LocalDateTime) value).toLocalDate();
        }
        try {
            return LocalDate.parse(value.toString().trim());
        } catch (Exception ex) {
            return null;
        }
    }

    private LocalDateTime toLocalDateTime(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof LocalDateTime) {
            return (LocalDateTime) value;
        }
        if (value instanceof Timestamp) {
            return ((Timestamp) value).toLocalDateTime();
        }
        if (value instanceof Date) {
            return ((Date) value).toLocalDate().atStartOfDay();
        }
        try {
            return LocalDateTime.parse(value.toString().trim());
        } catch (Exception ex) {
            return null;
        }
    }

    private String toString(Object value) {
        return value == null ? null : value.toString();
    }
}
