package com.example.TigoStarSystem.supervisor.controller;

import com.example.TigoStarSystem.common.ApiResponse;
import com.example.TigoStarSystem.supervisor.dto.ConformacionCuadrillaWebRequest;
import com.example.TigoStarSystem.supervisor.dto.ConformacionCuadrillaWebResponse;
import com.example.TigoStarSystem.supervisor.service.ConformacionCuadrillaWebService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Validated
@RestController
@RequestMapping("/supervisor/conformacion-cuadrilla-web")
public class ConformacionCuadrillaWebController {
    private final ConformacionCuadrillaWebService service;

    public ConformacionCuadrillaWebController(ConformacionCuadrillaWebService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<ConformacionCuadrillaWebResponse>>> listar(
            @RequestParam(value = "fecha", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha,
            @RequestParam(value = "sucursal", required = false) String sucursal,
            @RequestParam(value = "limite", required = false) Integer limite) {
        return ResponseEntity.ok(ApiResponse.of(
                service.listar(fecha, sucursal, limite),
                "Listado de conformacion cuadrilla web."
        ));
    }

    @GetMapping({"/catalogos/tecnicos", "/catalogos/tecnico"})
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> listarTecnicos(
            @RequestParam(value = "q", required = false) String q,
            @RequestParam(value = "limit", required = false) Integer limit) {
        return ResponseEntity.ok(ApiResponse.of(
                service.listarTecnicos(q, limit),
                "Listado de tecnicos para conformacion cuadrilla web."
        ));
    }

    @GetMapping({"/catalogos/tecnicos/{id}", "/catalogos/tecnico/{id}"})
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> obtenerTecnicoDetalle(
            @PathVariable("id") Integer id) {
        return ResponseEntity.ok(ApiResponse.of(
                service.obtenerTecnicoDetalle(id),
                "Detalle de tecnico para conformacion cuadrilla web."
        ));
    }

    @GetMapping({"/catalogos/auxiliares", "/catalogos/auxiliar"})
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> listarAuxiliares() {
        return ResponseEntity.ok(ApiResponse.of(
                service.listarAuxiliares(),
                "Listado de auxiliares para conformacion cuadrilla web."
        ));
    }

    @GetMapping({"/catalogos/digitadores", "/catalogos/digitador"})
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> listarDigitadores() {
        return ResponseEntity.ok(ApiResponse.of(
                service.listarDigitadores(),
                "Listado de digitadores para conformacion cuadrilla web."
        ));
    }

    @GetMapping({"/catalogos/supervisores", "/catalogos/supervisor"})
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> listarSupervisores() {
        return ResponseEntity.ok(ApiResponse.of(
                service.listarSupervisores(),
                "Listado de supervisores para conformacion cuadrilla web."
        ));
    }

    @GetMapping({"/catalogos/actividades", "/catalogos/actividad"})
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> listarActividades() {
        return ResponseEntity.ok(ApiResponse.of(
                service.listarActividades(),
                "Listado de actividades para conformacion cuadrilla web."
        ));
    }

    @GetMapping({"/catalogos/vehiculos", "/catalogos/vehiculo"})
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> listarVehiculos(
            @RequestParam(value = "filtro", required = false) String filtro) {
        return ResponseEntity.ok(ApiResponse.of(
                service.listarVehiculos(filtro),
                "Listado de vehiculos para conformacion cuadrilla web."
        ));
    }

    @GetMapping({"/catalogos/sucursales", "/catalogos/sucursal"})
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> listarSucursales() {
        return ResponseEntity.ok(ApiResponse.of(
                service.listarSucursales(),
                "Listado de sucursales para conformacion cuadrilla web."
        ));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ConformacionCuadrillaWebResponse>> obtenerPorId(
            @PathVariable("id") Long id) {
        return ResponseEntity.ok(ApiResponse.of(
                service.obtenerPorId(id),
                "Detalle de conformacion cuadrilla web."
        ));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<ConformacionCuadrillaWebResponse>> crear(
            @Valid @RequestBody ConformacionCuadrillaWebRequest request) {
        return ResponseEntity.ok(ApiResponse.of(
                service.crear(request),
                "Conformacion cuadrilla web registrada."
        ));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<ConformacionCuadrillaWebResponse>> actualizar(
            @PathVariable("id") Long id,
            @Valid @RequestBody ConformacionCuadrillaWebRequest request) {
        return ResponseEntity.ok(ApiResponse.of(
                service.actualizar(id, request),
                "Conformacion cuadrilla web actualizada."
        ));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Integer>> eliminar(@PathVariable("id") Long id) {
        return ResponseEntity.ok(ApiResponse.of(
                service.eliminar(id),
                "Conformacion cuadrilla web eliminada."
        ));
    }
}
