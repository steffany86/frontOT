package com.example.TigoStarSystem.auth.service;

import com.example.TigoStarSystem.auth.dto.AuthLoginRequest;
import com.example.TigoStarSystem.auth.dto.AuthLoginResponse;
import com.example.TigoStarSystem.auth.dto.AuthMeResponse;
import com.example.TigoStarSystem.auth.dto.SucursalResponse;
import com.example.TigoStarSystem.auth.repository.AuthRepository;
import com.example.TigoStarSystem.auth.repository.SucursalRepository;
import com.example.TigoStarSystem.common.ApiException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.Normalizer;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class AuthService {
    private static final Duration SESSION_TTL = Duration.ofHours(8);
    private static final Logger logger = LoggerFactory.getLogger(AuthService.class);
    private final AuthRepository authRepository;
    private final SucursalRepository sucursalRepository;
    private final JdbcTemplate defaultJdbcTemplate;
    private final Map<String, AuthSession> sessions = new ConcurrentHashMap<>();
    private final String dbUsername;
    private final String dbPassword;
    private final String dbDriver;
    private final String dbParams;
    private final String uTecnicosHost;
    private final String uTecnicosDatabase;
    private final String centralHost;
    private final String sucreLoginHost;
    private final String sucreLoginDatabase;
    private final String sucreLoginUsername;
    private final String sucreLoginPassword;
    private final boolean validarSucursal;
    private final boolean fallbackEnabled;

    public AuthService(
            AuthRepository authRepository,
            SucursalRepository sucursalRepository,
            JdbcTemplate defaultJdbcTemplate,
            @Value("${spring.datasource.username}") String dbUsername,
            @Value("${spring.datasource.password}") String dbPassword,
            @Value("${spring.datasource.driver-class-name}") String dbDriver,
            @Value("${spring.datasource.url}") String mainDatasourceUrl,
            @Value("${app.central.datasource.url:}") String centralDatasourceUrl,
            @Value("${app.sucre.datasource.url:}") String sucreDatasourceUrl,
            @Value("${auth.login.sucre.database:SucrePrueba}") String sucreLoginDatabase,
            @Value("${app.sucre.datasource.username:${spring.datasource.username}}") String sucreLoginUsername,
            @Value("${app.sucre.datasource.password:${spring.datasource.password}}") String sucreLoginPassword,
            @Value("${app.datasource.params:encrypt=false;trustServerCertificate=true}") String dbParams,
            @Value("${auth.login.validar-sucursal:true}") boolean validarSucursal,
            @Value("${auth.login.fallback-enabled:true}") boolean fallbackEnabled) {
        this.authRepository = authRepository;
        this.sucursalRepository = sucursalRepository;
        this.defaultJdbcTemplate = defaultJdbcTemplate;
        this.dbUsername = dbUsername;
        this.dbPassword = dbPassword;
        this.dbDriver = dbDriver;
        this.uTecnicosHost = parseHostFromJdbcUrl(mainDatasourceUrl);
        this.uTecnicosDatabase = parseDatabaseFromJdbcUrl(mainDatasourceUrl);
        String parsedCentralHost = parseHostFromJdbcUrl(centralDatasourceUrl);
        this.centralHost = isBlank(parsedCentralHost) ? this.uTecnicosHost : parsedCentralHost;
        String parsedSucreHost = parseHostFromJdbcUrl(sucreDatasourceUrl);
        String parsedSucreDatabase = parseDatabaseFromJdbcUrl(sucreDatasourceUrl);
        this.sucreLoginHost = firstNonBlank(parsedSucreHost, this.centralHost);
        this.sucreLoginDatabase = firstNonBlank(parsedSucreDatabase, sucreLoginDatabase);
        this.sucreLoginUsername = firstNonBlank(sucreLoginUsername, dbUsername);
        this.sucreLoginPassword = firstNonBlank(sucreLoginPassword, dbPassword);
        this.dbParams = dbParams;
        this.validarSucursal = validarSucursal;
        this.fallbackEnabled = fallbackEnabled;
    }

    public AuthSession login(AuthLoginRequest request) {
        logger.info(
                "Login attempt usuario={}, idSucursal={}, validarSucursal={}",
                safe(request == null ? null : request.getUsuario()),
                request == null ? null : request.getIdSucursal(),
                validarSucursal
        );
        SucursalInfo sucursal = obtenerSucursalPorId(request.getIdSucursal());
        logger.debug(
                "Sucursal resolved idSucursal={}, host={}, baseDeDatos={}",
                sucursal.idSucursal,
                sucursal.host,
                sucursal.baseDeDatos
        );
        SucursalInfo sucursalLogin = resolverDestinoLogin(sucursal);
        boolean esSucre = isSucre(normalizeText(sucursal == null ? null : sucursal.sucursal));
        logger.debug(
                "Login target resolved idSucursal={}, sucursal={}, host={}, baseDeDatos={}",
                sucursalLogin.idSucursal,
                sucursalLogin.sucursal,
                sucursalLogin.host,
                sucursalLogin.baseDeDatos
        );
        String loginUsername = esSucre ? sucreLoginUsername : dbUsername;
        String loginPassword = esSucre ? sucreLoginPassword : dbPassword;
        JdbcTemplate jdbcTemplate = crearJdbcTemplateSucursal(sucursalLogin, loginUsername, loginPassword);
        String passwordHash = hashMd5Base64(request.getPassword());

        List<Map<String, Object>> rows;
        try {
            rows = ejecutarValidacionConSpAlternativo(jdbcTemplate, request, passwordHash, validarSucursal);
        } catch (DataAccessException ex) {
            if (fallbackEnabled && !esSucre && isMissingStoredProcedure(ex)) {
                logger.warn(
                        "SP no encontrado en sucursal. Reintentando en BD por defecto usuario={}, idSucursal={}, validarSucursal={}",
                        safe(request.getUsuario()),
                        request.getIdSucursal(),
                        validarSucursal
                );
                rows = ejecutarValidacionConSpAlternativo(
                        defaultJdbcTemplate,
                        request,
                        passwordHash,
                        validarSucursal
                );
            } else {
                logger.error(
                        "Login SP failed usuario={}, idSucursal={}, host={}, baseDeDatos={}, validarSucursal={}",
                        safe(request.getUsuario()),
                        request.getIdSucursal(),
                        sucursalLogin.host,
                        sucursalLogin.baseDeDatos,
                        validarSucursal,
                        ex
                );
                throw ex;
            }
        } catch (Exception ex) {
            logger.error(
                    "Login SP failed usuario={}, idSucursal={}, host={}, baseDeDatos={}, validarSucursal={}",
                    safe(request.getUsuario()),
                    request.getIdSucursal(),
                    sucursalLogin.host,
                    sucursalLogin.baseDeDatos,
                    validarSucursal,
                    ex
            );
            throw ex;
        }
        logger.debug("Login SP returned {} rows", rows == null ? 0 : rows.size());
        if (rows == null || rows.isEmpty()) {
            logger.warn(
                    "Login invalid credentials usuario={}, idSucursal={}, validarSucursal={}",
                    safe(request.getUsuario()),
                    request.getIdSucursal(),
                    validarSucursal
            );
            throw new ApiException(HttpStatus.UNAUTHORIZED, "INVALID_CREDENTIALS", "Usuario o password invÃ¡lidos.");
        }
        AuthLoginResponse user = mapToResponse(rows.get(0), sucursal.idSucursal);
        String token = UUID.randomUUID().toString();
        OffsetDateTime expira = OffsetDateTime.now().plus(SESSION_TTL);
        AuthSession session = new AuthSession(token, user, expira);
        sessions.put(token, session);
        return session;
    }

    public List<SucursalResponse> listarSucursales() {
        List<Map<String, Object>> rows = sucursalRepository.obtenerSucursales();
        List<SucursalResponse> result = new ArrayList<>();
        for (Map<String, Object> row : rows) {
            SucursalInfo info = mapToSucursal(row);
            result.add(new SucursalResponse(info.idSucursal, info.sucursal, info.host, info.baseDeDatos));
        }
        return result;
    }

    public AuthMeResponse me(String token) {
        if (token == null || isBlank(token)) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "SESSION_REQUIRED", "SesiÃ³n requerida.");
        }
        AuthSession session = sessions.get(token);
        if (session == null) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "SESSION_INVALID", "SesiÃ³n invÃ¡lida.");
        }
        if (session.getExpira().isBefore(OffsetDateTime.now())) {
            sessions.remove(token);
            throw new ApiException(HttpStatus.UNAUTHORIZED, "SESSION_EXPIRED", "SesiÃ³n expirada.");
        }
        return new AuthMeResponse(session.getUsuario(), session.getExpira());
    }

    public AuthMeResponse requireAdmin(String token) {
        AuthMeResponse me = me(token);
        if (!esAdministrador(me.getUsuario())) {
            throw new ApiException(
                    HttpStatus.FORBIDDEN,
                    "FORBIDDEN_ADMIN_ONLY",
                    "Solo administradores pueden acceder a este recurso."
            );
        }
        return me;
    }

    public boolean esAdministrador(AuthLoginResponse usuario) {
        if (usuario == null) {
            return false;
        }
        if (usuario.getIdRol() != null && usuario.getIdRol() == 4) {
            return true;
        }
        String rol = usuario.getRol();
        if (rol == null || rol.trim().isEmpty()) {
            return false;
        }
        String normalized = normalizeText(rol);
        return normalized.contains("admin")
                || normalized.equals("sistemas")
                || normalized.contains("sistema");
    }

    private AuthLoginResponse mapToResponse(Map<String, Object> row, Integer idSucursalFallback) {
        Integer idUsuario = toInteger(findValue(row, "idusuario", "id_usuario", "iduser", "usuarioid"));
        Integer idRol = toInteger(findValue(row, "idrol", "id_rol", "rolid"));
        Integer idSucursal = toInteger(findValue(row, "idsucursal", "id_sucursal", "sucursalid"));
        if (idSucursal == null) {
            idSucursal = idSucursalFallback;
        }
        String nombre = toString(findValue(row, "nombre", "nombres", "nombreusuario", "usuario"));
        String rol = toString(findValue(row, "rol", "nombrerol", "descripcionrol"));

        if (idUsuario == null || nombre == null) {
            Map<String, Object> details = new HashMap<>();
            details.put("rowKeys", row.keySet());
            throw new ApiException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "INVALID_SP_RESULT",
                    "El SP spx_ValidarUsuario no devuelve las columnas esperadas.",
                    details
            );
        }
        return new AuthLoginResponse(idUsuario, nombre, rol, idRol, idSucursal);
    }

    private SucursalInfo obtenerSucursalPorId(Integer idSucursal) {
        if (idSucursal == null) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR", "idSucursal es requerido.");
        }
        List<Map<String, Object>> rows = sucursalRepository.obtenerSucursales();
        for (Map<String, Object> row : rows) {
            SucursalInfo info = mapToSucursal(row);
            if (idSucursal.equals(info.idSucursal)) {
                return info;
            }
        }
        throw new ApiException(HttpStatus.BAD_REQUEST, "SUCURSAL_NOT_FOUND", "Sucursal no encontrada.");
    }

    private SucursalInfo mapToSucursal(Map<String, Object> row) {
        Integer idSucursal = toInteger(findValue(row, "idsucursal", "id_sucursal"));
        String sucursal = toString(findValue(row, "sucursal"));
        String ip = toString(findValue(row, "ip"));
        String ip2 = toString(findValue(row, "ip2"));
        String baseDeDatos = toString(findValue(row, "basededatos", "base_de_datos"));

        String host = (ip != null && !isBlank(ip)) ? ip : ip2;
        if (idSucursal == null) {
            Map<String, Object> details = new HashMap<>();
            details.put("rowKeys", row.keySet());
            throw new ApiException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "INVALID_SUCURSAL_ROW",
                    "tbl_sucursal no contiene el campo requerido Id_Sucursal.",
                    details
            );
        }
        return new SucursalInfo(idSucursal, sucursal, trimToNull(host), trimToNull(baseDeDatos));
    }

    private SucursalInfo resolverDestinoLogin(SucursalInfo sucursalOriginal) {
        if (sucursalOriginal == null) {
            return sucursalOriginal;
        }

        boolean sucursalEsSucre = isSucre(normalizeText(sucursalOriginal.sucursal));
        String host = sucursalEsSucre
                ? firstNonBlank(sucreLoginHost, sucursalOriginal.host)
                : firstNonBlank(uTecnicosHost, sucursalOriginal.host);
        String database = sucursalEsSucre
                ? firstNonBlank(sucreLoginDatabase, sucursalOriginal.baseDeDatos)
                : firstNonBlank(uTecnicosDatabase, sucursalOriginal.baseDeDatos);

        if (isBlank(host) || isBlank(database)) {
            throw new ApiException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "SUCURSAL_DB_NOT_RESOLVED",
                    "No se pudo resolver host/base de datos para la sucursal seleccionada."
            );
        }
        return new SucursalInfo(
                sucursalOriginal.idSucursal,
                sucursalOriginal.sucursal,
                host.trim(),
                database.trim()
        );
    }

    private JdbcTemplate crearJdbcTemplateSucursal(SucursalInfo sucursal, String username, String password) {
        String url;
        if (dbDriver != null && dbDriver.toLowerCase(Locale.ROOT).contains("jtds")) {
            url = "jdbc:jtds:sqlserver://" + sucursal.host + "/" + sucursal.baseDeDatos;
        } else {
            url = "jdbc:sqlserver://" + sucursal.host + ";databaseName=" + sucursal.baseDeDatos;
        }
        if (dbParams != null && !isBlank(dbParams)) {
            url = url + (dbParams.startsWith(";") ? dbParams : ";" + dbParams);
        }
        logger.debug("Creating JDBC connection url={} driver={}", url, dbDriver);
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(dbDriver);
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        return new JdbcTemplate(dataSource);
    }

    private List<Map<String, Object>> ejecutarValidacion(
            JdbcTemplate template,
            AuthLoginRequest request,
            String passwordHash,
            boolean validarSucursal
    ) {
        if (validarSucursal) {
            logger.debug("Calling SP dbo.spx_ValidarUsuarioSucursal");
            return authRepository.validarUsuarioSucursal(
                    template,
                    request.getUsuario(),
                    passwordHash,
                    request.getIdSucursal()
            );
        }
        logger.debug("Calling SP dbo.spx_ValidarUsuario");
        return authRepository.validarUsuario(template, request.getUsuario(), passwordHash);
    }

    private List<Map<String, Object>> ejecutarValidacionConSpAlternativo(
            JdbcTemplate template,
            AuthLoginRequest request,
            String passwordHash,
            boolean validarSucursal
    ) {
        try {
            return ejecutarValidacion(template, request, passwordHash, validarSucursal);
        } catch (DataAccessException ex) {
            if (!isMissingStoredProcedure(ex)) {
                throw ex;
            }
            boolean validarSucursalAlternativo = !validarSucursal;
            logger.warn(
                    "SP de login no encontrado (validarSucursal={}). Reintentando con validarSucursal={} en la misma BD.",
                    validarSucursal,
                    validarSucursalAlternativo
            );
            return ejecutarValidacion(template, request, passwordHash, validarSucursalAlternativo);
        }
    }

    private String hashMd5Base64(String value) {
        if (value == null) {
            return null;
        }
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            byte[] digest = md5.digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(digest);
        } catch (NoSuchAlgorithmException ex) {
            throw new ApiException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "HASH_ERROR",
                    "No se pudo generar el hash MD5."
            );
        }
    }

    private Object findValue(Map<String, Object> row, String... candidates) {
        Map<String, Object> normalized = new HashMap<>();
        for (Map.Entry<String, Object> entry : row.entrySet()) {
            String key = normalize(entry.getKey());
            normalized.put(key, entry.getValue());
        }
        for (String candidate : candidates) {
            String key = normalize(candidate);
            if (normalized.containsKey(key)) {
                return normalized.get(key);
            }
        }
        return null;
    }

    private String normalize(String key) {
        return key == null ? "" : key.replace("_", "").toLowerCase(Locale.ROOT);
    }

    private String normalizeText(String value) {
        if (value == null) {
            return "";
        }
        String normalized = Normalizer.normalize(value, Normalizer.Form.NFD);
        normalized = normalized.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
        return normalized.trim().toLowerCase(Locale.ROOT);
    }

    private Integer toInteger(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        try {
            return Integer.parseInt(value.toString());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private String toString(Object value) {
        return value == null ? null : value.toString();
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private String firstNonBlank(String preferred, String fallback) {
        if (!isBlank(preferred)) {
            return preferred.trim();
        }
        return fallback;
    }

    private boolean isSucre(String value) {
        return value != null && value.contains("sucre");
    }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private String parseHostFromJdbcUrl(String jdbcUrl) {
        if (isBlank(jdbcUrl)) {
            return null;
        }
        String url = jdbcUrl.trim();
        int idx = url.indexOf("://");
        if (idx < 0) {
            return null;
        }
        String rest = url.substring(idx + 3);
        int sepSlash = rest.indexOf('/');
        int sepSemicolon = rest.indexOf(';');
        int end = -1;
        if (sepSlash >= 0 && sepSemicolon >= 0) {
            end = Math.min(sepSlash, sepSemicolon);
        } else if (sepSlash >= 0) {
            end = sepSlash;
        } else if (sepSemicolon >= 0) {
            end = sepSemicolon;
        }
        String hostPort = end >= 0 ? rest.substring(0, end) : rest;
        int comma = hostPort.indexOf(',');
        if (comma >= 0) {
            hostPort = hostPort.substring(0, comma);
        }
        int colon = hostPort.indexOf(':');
        if (colon >= 0) {
            hostPort = hostPort.substring(0, colon);
        }
        String host = hostPort.trim();
        return host.isEmpty() ? null : host;
    }

    private String parseDatabaseFromJdbcUrl(String jdbcUrl) {
        if (isBlank(jdbcUrl)) {
            return null;
        }
        String url = jdbcUrl.trim();
        String lower = url.toLowerCase(Locale.ROOT);
        String token = "databasename=";
        int idxDbName = lower.indexOf(token);
        if (idxDbName >= 0) {
            int start = idxDbName + token.length();
            int end = url.indexOf(';', start);
            String db = (end >= 0 ? url.substring(start, end) : url.substring(start)).trim();
            return db.isEmpty() ? null : db;
        }
        int idx = url.indexOf("://");
        if (idx < 0) {
            return null;
        }
        String rest = url.substring(idx + 3);
        int slash = rest.indexOf('/');
        if (slash < 0 || slash + 1 >= rest.length()) {
            return null;
        }
        String afterSlash = rest.substring(slash + 1);
        int end = afterSlash.indexOf(';');
        String db = (end >= 0 ? afterSlash.substring(0, end) : afterSlash).trim();
        return db.isEmpty() ? null : db;
    }

    private boolean isMissingStoredProcedure(DataAccessException ex) {
        Throwable root = ex;
        while (root.getCause() != null) {
            root = root.getCause();
        }
        if (root instanceof java.sql.SQLException) {
            java.sql.SQLException sqlEx = (java.sql.SQLException) root;
            if (sqlEx.getErrorCode() == 2812) {
                return true;
            }
            String msg = sqlEx.getMessage();
            if (msg != null) {
                String lower = msg.toLowerCase(Locale.ROOT);
                return lower.contains("procedimiento almacenado") && lower.contains("no se encontr");
            }
        }
        return false;
    }

    private String safe(String value) {
        if (value == null) {
            return null;
        }
        return value.trim();
    }

    private static final class SucursalInfo {
        private final Integer idSucursal;
        private final String sucursal;
        private final String host;
        private final String baseDeDatos;

        private SucursalInfo(Integer idSucursal, String sucursal, String host, String baseDeDatos) {
            this.idSucursal = idSucursal;
            this.sucursal = sucursal;
            this.host = host;
            this.baseDeDatos = baseDeDatos;
        }
    }
}
