package com.example.TigoStarSystem.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import javax.sql.DataSource;
import java.util.Locale;

@Configuration
public class CentralDbConfig {
    @Bean
    @Primary
    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean
    @Qualifier("centralJdbcTemplate")
    public JdbcTemplate centralJdbcTemplate(
            DataSource dataSource,
            @Value("${app.central.datasource.url:}") String centralUrl,
            @Value("${app.central.datasource.username:}") String centralUsername,
            @Value("${app.central.datasource.password:}") String centralPassword,
            @Value("${app.central.datasource.driver-class-name:}") String centralDriver,
            @Value("${app.central.datasource.hikari.pool-name:CentralHikariPool}") String poolName,
            @Value("${app.central.datasource.hikari.maximum-pool-size:${spring.datasource.hikari.maximum-pool-size:10}}") int maximumPoolSize,
            @Value("${app.central.datasource.hikari.minimum-idle:${spring.datasource.hikari.minimum-idle:2}}") int minimumIdle,
            @Value("${app.central.datasource.hikari.connection-timeout:${spring.datasource.hikari.connection-timeout:15000}}") long connectionTimeout,
            @Value("${app.central.datasource.hikari.validation-timeout:${spring.datasource.hikari.validation-timeout:5000}}") long validationTimeout,
            @Value("${app.central.datasource.hikari.idle-timeout:${spring.datasource.hikari.idle-timeout:300000}}") long idleTimeout,
            @Value("${app.central.datasource.hikari.max-lifetime:${spring.datasource.hikari.max-lifetime:900000}}") long maxLifetime,
            @Value("${app.central.datasource.hikari.keepalive-time:${spring.datasource.hikari.keepalive-time:120000}}") long keepaliveTime,
            @Value("${app.central.datasource.hikari.initialization-fail-timeout:${spring.datasource.hikari.initialization-fail-timeout:-1}}") long initializationFailTimeout,
            @Value("${app.central.datasource.hikari.connection-test-query:${spring.datasource.hikari.connection-test-query:SELECT 1}}") String connectionTestQuery,
            @Value("${spring.datasource.url}") String fallbackUrl,
            @Value("${spring.datasource.username}") String fallbackUsername,
            @Value("${spring.datasource.password}") String fallbackPassword,
            @Value("${spring.datasource.driver-class-name}") String fallbackDriver) {
        // Si la BD central es la misma que la principal, reutiliza el pool ya creado por Spring Boot.
        if (sameDatabaseConfig(
                centralUrl, centralUsername, centralPassword, centralDriver,
                fallbackUrl, fallbackUsername, fallbackPassword, fallbackDriver
        )) {
            return new JdbcTemplate(dataSource);
        }

        String url = isBlank(centralUrl) ? fallbackUrl : centralUrl;
        String username = isBlank(centralUsername) ? fallbackUsername : centralUsername;
        String password = isBlank(centralPassword) ? fallbackPassword : centralPassword;
        String driver = isBlank(centralDriver) ? fallbackDriver : centralDriver;

        HikariConfig config = new HikariConfig();
        config.setPoolName(poolName);
        config.setJdbcUrl(url);
        config.setUsername(username);
        config.setPassword(password);
        config.setDriverClassName(driver);
        config.setMaximumPoolSize(maximumPoolSize);
        config.setMinimumIdle(minimumIdle);
        config.setConnectionTimeout(connectionTimeout);
        config.setValidationTimeout(validationTimeout);
        config.setIdleTimeout(idleTimeout);
        config.setMaxLifetime(maxLifetime);
        config.setKeepaliveTime(keepaliveTime);
        config.setInitializationFailTimeout(initializationFailTimeout);
        config.setConnectionTestQuery(connectionTestQuery);
        return new JdbcTemplate(new HikariDataSource(config));
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private String normalize(String value) {
        return isBlank(value) ? "" : value.trim().toLowerCase(Locale.ROOT);
    }

    private boolean sameDatabaseConfig(
            String centralUrl,
            String centralUsername,
            String centralPassword,
            String centralDriver,
            String fallbackUrl,
            String fallbackUsername,
            String fallbackPassword,
            String fallbackDriver) {
        String resolvedCentralUrl = isBlank(centralUrl) ? fallbackUrl : centralUrl;
        String resolvedCentralUsername = isBlank(centralUsername) ? fallbackUsername : centralUsername;
        String resolvedCentralPassword = isBlank(centralPassword) ? fallbackPassword : centralPassword;
        String resolvedCentralDriver = isBlank(centralDriver) ? fallbackDriver : centralDriver;

        return normalize(resolvedCentralUrl).equals(normalize(fallbackUrl))
                && normalize(resolvedCentralUsername).equals(normalize(fallbackUsername))
                && normalize(resolvedCentralPassword).equals(normalize(fallbackPassword))
                && normalize(resolvedCentralDriver).equals(normalize(fallbackDriver));
    }
}
