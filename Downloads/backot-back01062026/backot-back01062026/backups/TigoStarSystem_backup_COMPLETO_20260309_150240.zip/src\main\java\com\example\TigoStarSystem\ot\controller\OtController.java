package com.example.TigoStarSystem.ot.controller;

import com.example.TigoStarSystem.auth.dto.AuthMeResponse;
import com.example.TigoStarSystem.auth.service.AuthService;
import com.example.TigoStarSystem.common.ApiException;
import com.example.TigoStarSystem.common.ApiResponse;
import com.example.TigoStarSystem.ot.dto.OtCrearRequest;
import com.example.TigoStarSystem.ot.dto.OtCrearResponse;
import com.example.TigoStarSystem.ot.dto.OtModificarDatosRequest;
import com.example.TigoStarSystem.ot.dto.OtModificarFechaRequest;
import com.example.TigoStarSystem.ot.dto.OtModificarFechaResponse;
import com.example.TigoStarSystem.ot.dto.OtRealizadaRequest;
import com.example.TigoStarSystem.ot.service.OtService;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Validated
@RestController
@RequestMapping("/ot")
public class OtController {
    private final OtService otService;
    private final AuthService authService;

    public OtController(OtService otService, AuthService authService) {
        this.otService = otService;
        this.authService = authService;
    }

    @PostMapping("/realizada")
    public ResponseEntity<ApiResponse<Integer>> registrarOtRealizada(@Valid @RequestBody OtRealizadaRequest request) {
        int filas = otService.registrarOtRealizada(request);
        return ResponseEntity.ok(ApiResponse.of(filas, "OT actualizada como realizada."));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<OtCrearResponse>> crearOt(
            @RequestHeader(value = "X-Session-Token", required = false) String token,
            @Valid @RequestBody OtCrearRequest request) {
        if (token != null && !token.trim().isEmpty()) {
            AuthMeResponse me = authService.me(token);
            if (me.getUsuario() != null && me.getUsuario().getRol() != null) {
                String rol = me.getUsuario().getRol().trim().toLowerCase();
                if (rol.equals("tecnico")) {
                    request.setIdUsuario(me.getUsuario().getIdUsuario());
                }
            }
        }
        OtCrearResponse response = otService.crearOt(request);
        return ResponseEntity.ok(ApiResponse.of(response, "OT registrada."));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> listarOt(
            @RequestParam(value = "fecha", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha,
            @RequestParam(value = "inicio", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate inicio,
            @RequestParam(value = "fin", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fin,
            @RequestParam(value = "usuario", required = false) Integer idUsuario,
            @RequestParam(value = "rol", required = false) String rol,
            @RequestParam(value = "pendiente", required = false) Boolean pendiente) {

        if (fecha != null) {
            return ResponseEntity.ok(ApiResponse.of(
                    otService.filtrarListado(
                            otService.listarPorFecha(fecha),
                            idUsuario,
                            rol,
                            pendiente),
                    "Listado de OT por fecha."));
        }
        if (inicio != null && fin != null) {
            return ResponseEntity.ok(ApiResponse.of(
                    otService.filtrarListado(
                            otService.listarPorRango(inicio, fin),
                            idUsuario,
                            rol,
                            pendiente),
                    "Listado de OT por rango."));
        }
        if (inicio == null && fin == null) {
            LocalDate hoy = LocalDate.now();
            return ResponseEntity.ok(ApiResponse.of(
                    otService.filtrarListado(
                            otService.listarPorFecha(hoy),
                            idUsuario,
                            rol,
                            pendiente),
                    "Listado de OT del dÃ­a."));
        }
        throw new ApiException(
                HttpStatus.BAD_REQUEST,
                "VALIDATION_ERROR",
                "Debe enviar 'fecha' o ambos 'inicio' y 'fin'."
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Map<String, Object>>> obtenerPorId(@PathVariable("id") Long id) {
        return ResponseEntity.ok(ApiResponse.of(
                otService.obtenerPorId(id),
                "OT encontrada."
        ));
    }

    @GetMapping("/numero/{numero}")
    public ResponseEntity<ApiResponse<Map<String, Object>>> obtenerPorNumero(
            @PathVariable("numero") @NotBlank String numero) {
        return ResponseEntity.ok(ApiResponse.of(
                otService.obtenerPorNumero(numero),
                "OT encontrada."
        ));
    }

    @GetMapping("/{id}/instalados")
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> obtenerInstalados(@PathVariable("id") Long id) {
        return ResponseEntity.ok(ApiResponse.of(
                otService.obtenerDetalleInstalado(id),
                "Detalle instalado."
        ));
    }

    @GetMapping("/{id}/retirados")
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> obtenerRetirados(@PathVariable("id") Long id) {
        return ResponseEntity.ok(ApiResponse.of(
                otService.obtenerDetalleRetirado(id),
                "Detalle retirado."
        ));
    }

    @GetMapping("/{id}/excedentes")
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> obtenerExcedentes(@PathVariable("id") Long id) {
        return ResponseEntity.ok(ApiResponse.of(
                otService.obtenerDetalleExcedente(id),
                "Detalle excedente."
        ));
    }

    @GetMapping("/{id}/cargo-usuario")
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> obtenerCargoUsuario(@PathVariable("id") Long id) {
        return ResponseEntity.ok(ApiResponse.of(
                otService.obtenerDetalleCargoUsuario(id),
                "Detalle cargo usuario."
        ));
    }

    @PutMapping("/{id}/datos")
    public ResponseEntity<ApiResponse<Integer>> modificarDatos(
            @PathVariable("id") Long id,
            @Valid @RequestBody OtModificarDatosRequest request) {
        int filas = otService.modificarDatosOt(id, request);
        return ResponseEntity.ok(ApiResponse.of(
                filas,
                "Datos de OT modificados."
        ));
    }

    @PutMapping("/{id}/fecha")
    public ResponseEntity<ApiResponse<OtModificarFechaResponse>> modificarFecha(
            @PathVariable("id") Long id,
            @Valid @RequestBody OtModificarFechaRequest request) {
        OtModificarFechaResponse response = otService.modificarFecha(id, request);
        return ResponseEntity.ok(ApiResponse.of(
                response,
                "Fecha de OT modificada."
        ));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Object>> anularOt(
            @PathVariable("id") Long id,
            @RequestParam("modo") String modo,
            @RequestParam(value = "usuario", required = false) Integer idUsuario) {
        if ("solo_cu".equalsIgnoreCase(modo)) {
            int filas = otService.anularSoloCu(id, idUsuario);
            return ResponseEntity.ok(ApiResponse.of(
                    filas,
                    "Cargo usuario anulado."
            ));
        }
        if ("con_cu".equalsIgnoreCase(modo)) {
            otService.anularConCu(id, idUsuario);
            return ResponseEntity.ok(ApiResponse.of(
                    null,
                    "OT anulada con CU."
            ));
        }
        throw new ApiException(
                HttpStatus.BAD_REQUEST,
                "VALIDATION_ERROR",
                "modo debe ser con_cu o solo_cu."
        );
    }
}

