package com.example.TigoStarSystem.ot.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Repository
public class OtRepository {
    private final JdbcTemplate jdbcTemplate;

    public OtRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Map<String, Object>> obtenerOrdenesPorFecha(LocalDate fecha) {
        return jdbcTemplate.queryForList(
                "EXEC sp_ObtenerListaOrdenesTrabajo ?",
                sqlDate(fecha)
        );
    }

    public List<Map<String, Object>> obtenerOrdenesPorRango(LocalDate inicio, LocalDate fin) {
        return jdbcTemplate.queryForList(
                "EXEC sp_ObtenerListaOrdenesTrabajoRFechas ?, ?",
                sqlDate(inicio),
                sqlDate(fin)
        );
    }

    public List<Map<String, Object>> obtenerOrdenTrabajoPorNumero(String numeroOrden) {
        return jdbcTemplate.queryForList(
                "EXEC sp_ObtenerOrdenTrabajo_X_Numero ?",
                numeroOrden
        );
    }

    public List<Map<String, Object>> obtenerOrdenTrabajoPorIdVenta(Long idVenta) {
        return jdbcTemplate.queryForList(
                "EXEC sp_ObtenerOrdenTrabajo_X_Id_Venta ?",
                idVenta
        );
    }

    public List<Map<String, Object>> obtenerOrdenTrabajoCompletaPorId(Long idVenta) {
        return jdbcTemplate.queryForList(
                "EXEC spx_ObtenerOrdeTrabajoCompletaXID ?",
                idVenta
        );
    }

    public List<Map<String, Object>> obtenerDetalleInstalado(Long idVenta) {
        return jdbcTemplate.queryForList(
                "EXEC sp_ObtenerDetalleVenta_Instalado_X_ID ?",
                idVenta
        );
    }

    public List<Map<String, Object>> obtenerDetalleRetirado(Long idVenta) {
        return jdbcTemplate.queryForList(
                "EXEC sp_ObtenerDetalleVenta_Retirado_X_ID ?",
                idVenta
        );
    }

    public List<Map<String, Object>> obtenerDetalleExcedente(Long idVenta) {
        return jdbcTemplate.queryForList(
                "EXEC sp_ObtenerDetalleVenta_Excedente_X_ID ?",
                idVenta
        );
    }

    public List<Map<String, Object>> obtenerDetalleCargoUsuario(Long idVenta) {
        return jdbcTemplate.queryForList(
                "EXEC sp_ObtenerDetalleVenta_CargoUsuario_X_ID ?",
                idVenta
        );
    }

    public int modificarOtRealizada(String observacion, Integer idEstado, String numeroOrden) {
        return jdbcTemplate.update(
                "EXEC sp_ModificarOT_OTRealizada ?, ?, ?",
                observacion,
                idEstado,
                numeroOrden
        );
    }

    public List<Map<String, Object>> validarCuadreRuta(Integer idRuta, LocalDate fecha) {
        return jdbcTemplate.queryForList(
                "EXEC spx_ValidarCuadreRuta ?, ?",
                idRuta,
                sqlDate(fecha)
        );
    }

    public List<Map<String, Object>> sePuedeModificarOrdenTrabajo(LocalDate fechaVieja, LocalDate fechaNueva, Integer idRuta) {
        return jdbcTemplate.queryForList(
                "EXEC spx_SePuedeModificarOrdenTrabajo ?, ?, ?",
                sqlDate(fechaVieja),
                sqlDate(fechaNueva),
                idRuta
        );
    }

    public int modificarOrdenTrabajoFecha(Integer idUsuario, LocalDate fechaNueva, Long idVenta) {
        return jdbcTemplate.update(
                "EXEC spx_ModificarOrdenTrabajoFecha ?, ?, ?",
                idUsuario,
                sqlDate(fechaNueva),
                idVenta
        );
    }

    public int eliminarCodigoUsuarioVenta(Long idVenta, Integer idUsuario) {
        return jdbcTemplate.update(
                "EXEC spx_EliminarCodigoUsuario_Venta ?, ?",
                idVenta,
                idUsuario
        );
    }

    public Map<String, Object> registrarOt(
            Integer idUsuario,
            Integer idRuta,
            Integer idTipoServicio,
            Integer codigoCliente,
            Integer idEstado,
            String observacion,
            Boolean tieneObservacion,
            Integer idSucursal,
            String nombreCliente
    ) {
        return jdbcTemplate.queryForMap(
                "EXEC spx_RegistrarOrdenTrabajo ?, ?, ?, ?, ?, ?, ?, ?, ?",
                idUsuario,
                idRuta,
                idTipoServicio,
                codigoCliente,
                idEstado,
                observacion,
                tieneObservacion == null ? Boolean.FALSE : tieneObservacion,
                idSucursal,
                nombreCliente
        );
    }

    private Date sqlDate(LocalDate date) {
        return Date.valueOf(date);
    }
}
