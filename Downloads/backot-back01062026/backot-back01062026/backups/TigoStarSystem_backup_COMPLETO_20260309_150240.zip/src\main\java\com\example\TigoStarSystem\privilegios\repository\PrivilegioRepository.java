package com.example.TigoStarSystem.privilegios.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class PrivilegioRepository {
    private final JdbcTemplate jdbcTemplate;

    public PrivilegioRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Map<String, Object>> listarRoles() {
        return jdbcTemplate.queryForList("EXEC dbo.spx_ObtenerPrivilegiosRoles");
    }

    public List<Map<String, Object>> obtenerPrivilegiosRolDetalle(Integer idRol) {
        return jdbcTemplate.queryForList(
                "EXEC dbo.spx_ObtenerPrivilegiosRolDetalle ?",
                idRol
        );
    }

    public List<Map<String, Object>> guardarPrivilegiosRol(Integer idRol, String menuIdsCsv) {
        return jdbcTemplate.queryForList(
                "EXEC dbo.spx_GuardarPrivilegiosRol ?, ?",
                idRol,
                menuIdsCsv
        );
    }
}
