package com.example.TigoStarSystem.supervisor.repository;

import com.example.TigoStarSystem.auth.repository.SucursalRepository;
import com.example.TigoStarSystem.supervisor.dto.ConformacionCuadrillaRowRequest;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

@Repository
public class ConformacionCuadrillaRepository {
    private final JdbcTemplate centralJdbcTemplate;
    private final JdbcTemplate jdbcTemplate;
    private final SucursalRepository sucursalRepository;
    private final String dbUsername;
    private final String dbPassword;
    private final String dbDriver;
    private final String dbParams;
    private final String uTecnicosHost;
    private final String uTecnicosDatabase;
    private final String centralHost;
    private final String sucreHost;
    private final String sucreDatabase;
    private final String sucreUsername;
    private final String sucrePassword;

    public ConformacionCuadrillaRepository(
            @Qualifier("centralJdbcTemplate") JdbcTemplate centralJdbcTemplate,
            JdbcTemplate jdbcTemplate,
            SucursalRepository sucursalRepository,
            @Value("${spring.datasource.username}") String dbUsername,
            @Value("${spring.datasource.password}") String dbPassword,
            @Value("${spring.datasource.driver-class-name}") String dbDriver,
            @Value("${spring.datasource.url}") String mainDatasourceUrl,
            @Value("${app.central.datasource.url:}") String centralDatasourceUrl,
            @Value("${app.sucre.datasource.url:}") String sucreDatasourceUrl,
            @Value("${auth.login.sucre.database:SucrePrueba}") String sucreDatabase,
            @Value("${app.sucre.datasource.username:${spring.datasource.username}}") String sucreUsername,
            @Value("${app.sucre.datasource.password:${spring.datasource.password}}") String sucrePassword,
            @Value("${app.datasource.params:encrypt=false;trustServerCertificate=true}") String dbParams) {
        this.centralJdbcTemplate = centralJdbcTemplate;
        this.jdbcTemplate = jdbcTemplate;
        this.sucursalRepository = sucursalRepository;
        this.dbUsername = dbUsername;
        this.dbPassword = dbPassword;
        this.dbDriver = dbDriver;
        this.uTecnicosHost = parseHostFromJdbcUrl(mainDatasourceUrl);
        this.uTecnicosDatabase = parseDatabaseFromJdbcUrl(mainDatasourceUrl);
        String parsedCentralHost = parseHostFromJdbcUrl(centralDatasourceUrl);
        this.centralHost = isBlank(parsedCentralHost) ? this.uTecnicosHost : parsedCentralHost;
        String parsedSucreHost = parseHostFromJdbcUrl(sucreDatasourceUrl);
        String parsedSucreDatabase = parseDatabaseFromJdbcUrl(sucreDatasourceUrl);
        this.sucreHost = firstNonBlank(parsedSucreHost, this.centralHost);
        this.sucreDatabase = firstNonBlank(parsedSucreDatabase, sucreDatabase);
        this.sucreUsername = firstNonBlank(sucreUsername, this.dbUsername);
        this.sucrePassword = firstNonBlank(sucrePassword, this.dbPassword);
        this.dbParams = dbParams;
    }

    public List<Map<String, Object>> listar(LocalDate fecha, String sucursal, Integer limite, Integer idTecnico) {
        Object fechaParam = fecha == null ? null : Date.valueOf(fecha);
        String sucursalParam = (sucursal == null || sucursal.trim().isEmpty()) ? null : sucursal.trim();
        SucursalDbInfo dbInfo = sucursalParam == null ? null : resolverSucursalDbInfo(sucursalParam);
        Set<String> filtrosConsulta = construirFiltrosConsulta(sucursalParam, dbInfo);

        try {
            for (String filtro : filtrosConsulta) {
                List<Map<String, Object>> rowsCentral =
                        listarEnTemplate(centralJdbcTemplate, fechaParam, filtro, limite, idTecnico);
                if (rowsCentral != null && !rowsCentral.isEmpty()) {
                    return rowsCentral;
                }
            }
        } catch (DataAccessException ex) {
            // fallback final
        }

        List<Map<String, Object>> rowsSucursal = listarEnSucursalSeleccionada(
                sucursalParam,
                fechaParam,
                limite,
                idTecnico,
                dbInfo
        );
        if (rowsSucursal != null && !rowsSucursal.isEmpty()) {
            return rowsSucursal;
        }

        for (String filtro : filtrosConsulta) {
            List<Map<String, Object>> rows = listarEnTemplate(jdbcTemplate, fechaParam, filtro, limite, idTecnico);
            if (rows != null && !rows.isEmpty()) {
                return rows;
            }
        }
        return new ArrayList<>();
    }

    public Map<String, Object> obtenerPorId(Long id) {
        if (id == null) {
            return null;
        }
        Map<String, Object> rowCentral = obtenerPorIdEnTemplate(centralJdbcTemplate, id);
        if (rowCentral != null) {
            return rowCentral;
        }
        return obtenerPorIdEnTemplate(jdbcTemplate, id);
    }

    public List<Map<String, Object>> listarConEliminados(
            LocalDate fecha,
            String sucursal,
            Integer limite,
            Integer idTecnico) {
        Object fechaParam = fecha == null ? null : Date.valueOf(fecha);
        String sucursalParam = (sucursal == null || sucursal.trim().isEmpty()) ? null : sucursal.trim();
        SucursalDbInfo dbInfo = sucursalParam == null ? null : resolverSucursalDbInfo(sucursalParam);
        Set<String> filtrosConsulta = construirFiltrosConsulta(sucursalParam, dbInfo);

        try {
            for (String filtro : filtrosConsulta) {
                List<Map<String, Object>> rowsCentral = listarConEliminadosEnTemplate(
                        centralJdbcTemplate,
                        fechaParam,
                        filtro,
                        limite,
                        idTecnico
                );
                if (rowsCentral != null && !rowsCentral.isEmpty()) {
                    return rowsCentral;
                }
            }
        } catch (DataAccessException ex) {
            // fallback final
        }

        List<Map<String, Object>> rowsSucursal = listarConEliminadosEnSucursalSeleccionada(
                sucursalParam,
                fechaParam,
                limite,
                idTecnico,
                dbInfo
        );
        if (rowsSucursal != null && !rowsSucursal.isEmpty()) {
            return rowsSucursal;
        }

        for (String filtro : filtrosConsulta) {
            try {
                List<Map<String, Object>> rows = listarConEliminadosEnTemplate(
                        jdbcTemplate,
                        fechaParam,
                        filtro,
                        limite,
                        idTecnico
                );
                if (rows != null && !rows.isEmpty()) {
                    return rows;
                }
            } catch (DataAccessException ex) {
                // sin fallback adicional
            }
        }
        return new ArrayList<>();
    }

    private List<Map<String, Object>> listarEnTemplate(
            JdbcTemplate template,
            Object fechaParam,
            String sucursalParam,
            Integer limite,
            Integer idTecnico) {
        try {
            try {
                return template.queryForList(
                        "EXEC dbo.spx_ObtenerConformacionCuadrillaBackOffice ?, ?, ?, ?",
                        fechaParam,
                        sucursalParam,
                        limite,
                        idTecnico
                );
            } catch (DataAccessException exV4) {
                List<Map<String, Object>> rows = template.queryForList(
                        "EXEC dbo.spx_ObtenerConformacionCuadrillaBackOffice ?, ?, ?",
                        fechaParam,
                        sucursalParam,
                        limite
                );
                return filtrarPorTecnicoId(rows, idTecnico);
            }
        } catch (DataAccessException ex) {
            try {
                return template.queryForList(
                        "EXEC dbo.spx_ObtenerListadoConformacionCuadrillaBackOffice ?, ?, ?, ?",
                        fechaParam,
                        sucursalParam,
                        limite,
                        idTecnico
                );
            } catch (DataAccessException exV4Listado) {
                List<Map<String, Object>> rows = template.queryForList(
                        "EXEC dbo.spx_ObtenerListadoConformacionCuadrillaBackOffice ?, ?, ?",
                        fechaParam,
                        sucursalParam,
                        limite
                );
                return filtrarPorTecnicoId(rows, idTecnico);
            }
        }
    }

    private Map<String, Object> obtenerPorIdEnTemplate(JdbcTemplate template, Long id) {
        try {
            List<Map<String, Object>> rows = queryForList(
                    template,
                    "SELECT TOP 1 * FROM dbo.tbl_ConformacionCuadrillaDiario WHERE id = ? ORDER BY id DESC",
                    id
            );
            if (rows == null || rows.isEmpty()) {
                return null;
            }
            return rows.get(0);
        } catch (DataAccessException ex) {
            return null;
        }
    }

    private List<Map<String, Object>> listarConEliminadosEnTemplate(
            JdbcTemplate template,
            Object fechaParam,
            String sucursalParam,
            Integer limite,
            Integer idTecnico) {
        StringBuilder sql = new StringBuilder(
                "SELECT * FROM dbo.tbl_ConformacionCuadrillaDiario WHERE 1=1"
        );
        List<Object> args = new ArrayList<>();
        if (fechaParam != null) {
            sql.append(" AND fecha = ?");
            args.add(fechaParam);
        }
        if (!isBlank(sucursalParam)) {
            sql.append(" AND sucursal = ?");
            args.add(sucursalParam.trim());
        }
        if (idTecnico != null) {
            sql.append(" AND id_tecnico = ?");
            args.add(idTecnico);
        }
        sql.append(" ORDER BY fechaRegistro DESC, id DESC");

        List<Map<String, Object>> rows = queryForList(template, sql.toString(), args.toArray());
        if (rows == null || rows.isEmpty()) {
            return rows;
        }
        if (limite == null || limite <= 0 || rows.size() <= limite) {
            return rows;
        }
        return new ArrayList<>(rows.subList(0, limite));
    }

    public int guardarFilaConfirmada(ConformacionCuadrillaRowRequest fila) {
        return ejecutarRegistrar(centralJdbcTemplate, fila);
    }

    public int actualizarFila(Long id, ConformacionCuadrillaRowRequest fila) {
        return ejecutarActualizar(centralJdbcTemplate, id, fila);
    }

    public List<Map<String, Object>> listarTecnicos() {
        return queryForListFallback("EXEC dbo.spx_TraerVendedores_x_FormTecnico");
    }

    public List<Map<String, Object>> listarTecnicosFiltroEdicion() {
        try {
            return queryForListFallback("EXEC dbo.spr_TraerVendedores_x_FormTecnico");
        } catch (DataAccessException ex) {
            return queryForListFallback("EXEC dbo.spx_TraerVendedores_x_FormTecnico");
        }
    }

    public List<Map<String, Object>> listarAuxiliares() {
        return queryForListFallback("EXEC dbo.spx_TraerVendedores_x_FormTecnico");
    }

    public List<Map<String, Object>> obtenerTecnicoDetalle(Integer idTecnico) {
        return queryForListFallback("EXEC dbo.spx_ObtenerDatosTecnicoCuadrilla ?", idTecnico);
    }

    public List<Map<String, Object>> listarDigitadores() {
        return queryForListFallback("EXEC dbo.spx_ObtenerDigitadores");
    }

    public List<Map<String, Object>> listarDigitadoresFiltroEdicion() {
        try {
            return queryForListFallback("EXEC dbo.spx_ObtenerListaDigitadores");
        } catch (DataAccessException ex) {
            return queryForListFallback("EXEC dbo.spx_ObtenerDigitadores");
        }
    }

    public List<Map<String, Object>> listarSupervisores() {
        return queryForListFallback("EXEC dbo.spx_ObtenerSupervisores");
    }

    public List<Map<String, Object>> listarVehiculos(String filtro) {
        String filtroParam = (filtro == null || filtro.trim().isEmpty()) ? null : filtro.trim();
        return queryForListFallback("EXEC dbo.[listar-vehiculo] ?", filtroParam);
    }

    public List<Map<String, Object>> listarVehiculosFiltroEdicion(Integer idTecnico) {
        if (idTecnico != null) {
            try {
                return queryForListFallback("EXEC dbo.spx_ObtenerPlacavehiculos_Tecnico ?", idTecnico);
            } catch (DataAccessException ex) {
                // fallback sin parametro
            }
        }
        try {
            return queryForListFallback("EXEC dbo.spx_ObtenerPlacavehiculos_Tecnico");
        } catch (DataAccessException ex) {
            return listarVehiculos(null);
        }
    }

    public List<Map<String, Object>> listarGruposFiltroEdicion() {
        return listarGruposFiltroEdicion(null);
    }

    public List<Map<String, Object>> listarGruposFiltroEdicion(String sucursal) {
        String sql = "EXEC dbo.spx_ObtenerRutaXIdTecnico";

        try {
            List<Map<String, Object>> operativa = queryForList(jdbcTemplate, sql);
            if (operativa != null && !operativa.isEmpty()) {
                return operativa;
            }
        } catch (DataAccessException ex) {
            // fallback a sucursal seleccionada
        }

        SucursalDbInfo dbInfo = isBlank(sucursal) ? null : resolverSucursalDbInfo(sucursal);
        if (dbInfo != null) {
            try {
                JdbcTemplate sucursalTemplate = crearJdbcTemplateSucursal(
                        dbInfo.host,
                        dbInfo.baseDeDatos,
                        dbInfo.username,
                        dbInfo.password
                );
                List<Map<String, Object>> rowsSucursal = queryForList(sucursalTemplate, sql);
                if (rowsSucursal != null && !rowsSucursal.isEmpty()) {
                    return rowsSucursal;
                }
            } catch (DataAccessException ex) {
                // sin fallback a BDControlOrdenes para catalogo de cuadrillas
            }
        }

        if (isSucre(normalizeText(sucursal))) {
            try {
                JdbcTemplate sucreTemplate = crearJdbcTemplateSucursal(
                        sucreHost,
                        sucreDatabase,
                        sucreUsername,
                        sucrePassword
                );
                List<Map<String, Object>> rowsSucre = queryForList(sucreTemplate, sql);
                if (rowsSucre != null && !rowsSucre.isEmpty()) {
                    return rowsSucre;
                }
            } catch (DataAccessException ex) {
                // sin fallback adicional
            }
        }

        return new ArrayList<>();
    }

    public List<Map<String, Object>> obtenerSucursalActual() {
        List<Map<String, Object>> rows = sucursalRepository.obtenerSucursales();
        List<Map<String, Object>> out = new ArrayList<>();
        if (rows == null || rows.isEmpty()) {
            return out;
        }
        Set<String> seen = new HashSet<>();
        for (Map<String, Object> row : rows) {
            Integer id = asInteger(firstNonNull(row, "idsucursal", "id_sucursal", "Id_Sucursal"));
            String nombre = asString(firstNonNull(row, "sucursal", "Sucursal"));
            if (isBlank(nombre)) {
                continue;
            }
            String key = nombre.trim().toUpperCase(Locale.ROOT);
            if (!seen.add(key)) {
                continue;
            }
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("idSucursal", id);
            item.put("sucursal", nombre.trim());
            out.add(item);
        }
        return out;
    }

    private List<Map<String, Object>> queryForListFallback(String sql, Object... args) {
        try {
            List<Map<String, Object>> operativa = queryForList(jdbcTemplate, sql, args);
            if (operativa != null && !operativa.isEmpty()) {
                return operativa;
            }
        } catch (DataAccessException ex) {
            // fallback below
        }
        try {
            List<Map<String, Object>> central = queryForList(centralJdbcTemplate, sql, args);
            return central == null ? new ArrayList<>() : central;
        } catch (DataAccessException ex) {
            return new ArrayList<>();
        }
    }

    private List<Map<String, Object>> queryForList(JdbcTemplate template, String sql, Object... args) {
        if (args == null || args.length == 0) {
            return template.queryForList(sql);
        }
        return template.queryForList(sql, args);
    }

    private List<Map<String, Object>> filtrarPorTecnicoId(List<Map<String, Object>> rows, Integer idTecnico) {
        if (idTecnico == null || rows == null || rows.isEmpty()) {
            return rows;
        }
        List<Map<String, Object>> filtered = new ArrayList<>();
        for (Map<String, Object> row : rows) {
            Integer value = asInteger(
                    firstNonNull(row, "id_tecnico", "Id_Tecnico", "idTecnico", "idTecnicoTitular")
            );
            if (value != null && value.equals(idTecnico)) {
                filtered.add(row);
            }
        }
        return filtered;
    }

    private Object firstNonNull(Map<String, Object> row, String... keys) {
        if (row == null || keys == null) {
            return null;
        }
        for (String key : keys) {
            if (row.containsKey(key) && row.get(key) != null) {
                return row.get(key);
            }
        }
        return null;
    }

    private Integer asInteger(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        try {
            return Integer.parseInt(String.valueOf(value).trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private int ejecutarRegistrar(JdbcTemplate template, ConformacionCuadrillaRowRequest fila) {
        return template.update(
                "EXEC dbo.spx_RegistrarConformacionCuadrillaBackOffice " +
                        "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?",
                fila.getFecha() == null ? null : Date.valueOf(fila.getFecha()),
                fila.getEstado(),
                fila.getActividad(),
                fila.getIdTecnico(),
                fila.getCuentaSf(),
                fila.getSalesforce(),
                fila.getHabilidad(),
                fila.getVehiculo(),
                fila.getGrupo(),
                fila.getAlmacen(),
                fila.getGrupoDigitacion(),
                fila.getIdUsuarioDigitador(),
                fila.getDigitador(),
                fila.getTecnico(),
                fila.getIdTecnicoAuxiliar(),
                fila.getAuxiliar(),
                fila.getIdUsuarioSupervisor(),
                fila.getSupervisorACargo(),
                fila.getSucursal(),
                fila.getObservacion(),
                fila.getIdUsuarioRegistra()
        );
    }

    private int ejecutarActualizar(JdbcTemplate template, Long id, ConformacionCuadrillaRowRequest fila) {
        return template.update(
                "EXEC dbo.spx_ActualizarConformacionCuadrillaBackOffice " +
                        "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?",
                id,
                fila.getFecha() == null ? null : Date.valueOf(fila.getFecha()),
                fila.getEstado(),
                fila.getActividad(),
                fila.getIdTecnico(),
                fila.getCuentaSf(),
                fila.getSalesforce(),
                fila.getHabilidad(),
                fila.getVehiculo(),
                fila.getGrupo(),
                fila.getAlmacen(),
                fila.getGrupoDigitacion(),
                fila.getIdUsuarioDigitador(),
                fila.getDigitador(),
                fila.getTecnico(),
                fila.getIdTecnicoAuxiliar(),
                fila.getAuxiliar(),
                fila.getIdUsuarioSupervisor(),
                fila.getSupervisorACargo(),
                fila.getSucursal(),
                fila.getObservacion(),
                fila.getIdUsuarioRegistra()
        );
    }

    private List<Map<String, Object>> listarEnSucursalSeleccionada(
            String sucursalParam,
            Object fechaParam,
            Integer limite,
            Integer idTecnico,
            SucursalDbInfo dbInfo) {
        if (sucursalParam == null || sucursalParam.trim().isEmpty()) {
            return new ArrayList<>();
        }
        if (dbInfo == null) {
            return new ArrayList<>();
        }
        JdbcTemplate sucursalTemplate = crearJdbcTemplateSucursal(
                dbInfo.host,
                dbInfo.baseDeDatos,
                dbInfo.username,
                dbInfo.password
        );
        Set<String> filtros = construirFiltrosConsulta(sucursalParam, dbInfo);
        try {
            for (String filtro : filtros) {
                List<Map<String, Object>> rows = listarEnTemplate(
                        sucursalTemplate,
                        fechaParam,
                        filtro,
                        limite,
                        idTecnico
                );
                if (rows != null && !rows.isEmpty()) {
                    return rows;
                }
            }
            return new ArrayList<>();
        } catch (DataAccessException ex) {
            return new ArrayList<>();
        }
    }

    private List<Map<String, Object>> listarConEliminadosEnSucursalSeleccionada(
            String sucursalParam,
            Object fechaParam,
            Integer limite,
            Integer idTecnico,
            SucursalDbInfo dbInfo) {
        if (sucursalParam == null || sucursalParam.trim().isEmpty()) {
            return new ArrayList<>();
        }
        if (dbInfo == null) {
            return new ArrayList<>();
        }
        JdbcTemplate sucursalTemplate = crearJdbcTemplateSucursal(
                dbInfo.host,
                dbInfo.baseDeDatos,
                dbInfo.username,
                dbInfo.password
        );
        Set<String> filtros = construirFiltrosConsulta(sucursalParam, dbInfo);
        try {
            for (String filtro : filtros) {
                List<Map<String, Object>> rows = listarConEliminadosEnTemplate(
                        sucursalTemplate,
                        fechaParam,
                        filtro,
                        limite,
                        idTecnico
                );
                if (rows != null && !rows.isEmpty()) {
                    return rows;
                }
            }
            return new ArrayList<>();
        } catch (DataAccessException ex) {
            return new ArrayList<>();
        }
    }

    private SucursalDbInfo resolverSucursalDbInfo(String sucursalParam) {
        List<Map<String, Object>> sucursales = sucursalRepository.obtenerSucursales();
        if (sucursales == null) {
            sucursales = new ArrayList<>();
        }
        Integer idBuscado = parseInteger(sucursalParam);
        String nombreBuscado = normalizeText(sucursalParam);
        Map<String, Object> sucursalMatch = null;
        for (Map<String, Object> row : sucursales) {
            Integer id = asInteger(firstNonNull(row, "idsucursal", "id_sucursal", "Id_Sucursal"));
            String nombre = asString(firstNonNull(row, "sucursal", "Sucursal"));
            boolean matchId = idBuscado != null && id != null && idBuscado.equals(id);
            boolean matchNombre = !nombreBuscado.isEmpty() && !normalizeText(nombre).isEmpty()
                    && nombreBuscado.equals(normalizeText(nombre));
            if (matchId || matchNombre) {
                sucursalMatch = row;
                break;
            }
        }

        Integer idSucursal = asInteger(
                sucursalMatch == null ? null : firstNonNull(sucursalMatch, "idsucursal", "id_sucursal", "Id_Sucursal")
        );
        String nombreSucursalRaw = asString(
                sucursalMatch == null ? null : firstNonNull(sucursalMatch, "sucursal", "Sucursal")
        );
        String nombreSucursal = normalizeText(nombreSucursalRaw);
        String hostSucursal = asString(
                sucursalMatch == null ? null : firstNonNull(sucursalMatch, "ip", "IP", "ip2", "IP2")
        );
        String baseSucursal = asString(
                sucursalMatch == null ? null : firstNonNull(sucursalMatch, "basededatos", "base_de_datos", "BaseDeDatos")
        );

        if (isSucre(nombreSucursal) || isSucre(nombreBuscado)) {
            return buildDbInfo(
                    sucreHost,
                    sucreDatabase,
                    hostSucursal,
                    baseSucursal,
                    sucreUsername,
                    sucrePassword,
                    dbUsername,
                    dbPassword,
                    firstNonNull(idSucursal, idBuscado),
                    firstNonBlank(nombreSucursalRaw, sucursalParam)
            );
        }
        return buildDbInfo(
                uTecnicosHost,
                uTecnicosDatabase,
                hostSucursal,
                baseSucursal,
                dbUsername,
                dbPassword,
                dbUsername,
                dbPassword,
                firstNonNull(idSucursal, idBuscado),
                firstNonBlank(nombreSucursalRaw, sucursalParam)
        );
    }

    private JdbcTemplate crearJdbcTemplateSucursal(String host, String baseDeDatos, String username, String password) {
        String url;
        if (dbDriver != null && dbDriver.toLowerCase(Locale.ROOT).contains("jtds")) {
            url = "jdbc:jtds:sqlserver://" + host + "/" + baseDeDatos;
        } else {
            url = "jdbc:sqlserver://" + host + ";databaseName=" + baseDeDatos;
        }
        if (dbParams != null && !dbParams.trim().isEmpty()) {
            url = url + (dbParams.startsWith(";") ? dbParams : ";" + dbParams);
        }
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(dbDriver);
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        return new JdbcTemplate(dataSource);
    }

    private String normalizeText(String value) {
        if (value == null) {
            return "";
        }
        return value.trim().toLowerCase(Locale.ROOT);
    }

    private String asString(Object value) {
        return value == null ? null : value.toString();
    }

    private Integer parseInteger(String value) {
        if (value == null) {
            return null;
        }
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private boolean isSucre(String value) {
        return value != null && value.contains("sucre");
    }

    private SucursalDbInfo buildDbInfo(
            String preferredHost,
            String preferredDatabase,
            String fallbackHost,
            String fallbackDatabase,
            String preferredUsername,
            String preferredPassword,
            String fallbackUsername,
            String fallbackPassword,
            Integer idSucursal,
            String nombreSucursal) {
        String host = firstNonBlank(preferredHost, fallbackHost);
        String database = firstNonBlank(preferredDatabase, fallbackDatabase);
        String username = firstNonBlank(preferredUsername, fallbackUsername);
        String password = firstNonBlank(preferredPassword, fallbackPassword);
        if (isBlank(host) || isBlank(database) || isBlank(username) || isBlank(password)) {
            return null;
        }
        return new SucursalDbInfo(
                host.trim(),
                database.trim(),
                username.trim(),
                password.trim(),
                idSucursal,
                isBlank(nombreSucursal) ? null : nombreSucursal.trim()
        );
    }

    private Integer firstNonNull(Integer preferred, Integer fallback) {
        return preferred != null ? preferred : fallback;
    }

    private void addFiltro(Set<String> filtros, String value) {
        if (filtros == null || isBlank(value)) {
            return;
        }
        filtros.add(value.trim());
    }

    private Set<String> construirFiltrosConsulta(String sucursalParam, SucursalDbInfo dbInfo) {
        Set<String> filtros = new LinkedHashSet<>();
        if (isBlank(sucursalParam)) {
            filtros.add(null);
            return filtros;
        }
        addFiltro(filtros, sucursalParam);
        if (dbInfo != null) {
            addFiltro(filtros, dbInfo.idSucursal == null ? null : String.valueOf(dbInfo.idSucursal));
            addFiltro(filtros, dbInfo.nombreSucursal);
        }
        return filtros;
    }

    private String firstNonBlank(String preferred, String fallback) {
        if (!isBlank(preferred)) {
            return preferred.trim();
        }
        return fallback;
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private String parseHostFromJdbcUrl(String jdbcUrl) {
        if (isBlank(jdbcUrl)) {
            return null;
        }
        String url = jdbcUrl.trim();
        int idx = url.indexOf("://");
        if (idx < 0) {
            return null;
        }
        String rest = url.substring(idx + 3);
        int sepSlash = rest.indexOf('/');
        int sepSemicolon = rest.indexOf(';');
        int end = -1;
        if (sepSlash >= 0 && sepSemicolon >= 0) {
            end = Math.min(sepSlash, sepSemicolon);
        } else if (sepSlash >= 0) {
            end = sepSlash;
        } else if (sepSemicolon >= 0) {
            end = sepSemicolon;
        }
        String hostPort = end >= 0 ? rest.substring(0, end) : rest;
        int comma = hostPort.indexOf(',');
        if (comma >= 0) {
            hostPort = hostPort.substring(0, comma);
        }
        int colon = hostPort.indexOf(':');
        if (colon >= 0) {
            hostPort = hostPort.substring(0, colon);
        }
        String host = hostPort.trim();
        return host.isEmpty() ? null : host;
    }

    private String parseDatabaseFromJdbcUrl(String jdbcUrl) {
        if (isBlank(jdbcUrl)) {
            return null;
        }
        String url = jdbcUrl.trim();
        String lower = url.toLowerCase(Locale.ROOT);
        String token = "databasename=";
        int idxDbName = lower.indexOf(token);
        if (idxDbName >= 0) {
            int start = idxDbName + token.length();
            int end = url.indexOf(';', start);
            String db = (end >= 0 ? url.substring(start, end) : url.substring(start)).trim();
            return db.isEmpty() ? null : db;
        }
        int idx = url.indexOf("://");
        if (idx < 0) {
            return null;
        }
        String rest = url.substring(idx + 3);
        int slash = rest.indexOf('/');
        if (slash < 0 || slash + 1 >= rest.length()) {
            return null;
        }
        String afterSlash = rest.substring(slash + 1);
        int end = afterSlash.indexOf(';');
        String db = (end >= 0 ? afterSlash.substring(0, end) : afterSlash).trim();
        return db.isEmpty() ? null : db;
    }

    private static final class SucursalDbInfo {
        private final String host;
        private final String baseDeDatos;
        private final String username;
        private final String password;
        private final Integer idSucursal;
        private final String nombreSucursal;

        private SucursalDbInfo(
                String host,
                String baseDeDatos,
                String username,
                String password,
                Integer idSucursal,
                String nombreSucursal) {
            this.host = host;
            this.baseDeDatos = baseDeDatos;
            this.username = username;
            this.password = password;
            this.idSucursal = idSucursal;
            this.nombreSucursal = nombreSucursal;
        }
    }
}
