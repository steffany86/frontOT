package com.example.TigoStarSystem.supervisor.service;

import com.example.TigoStarSystem.supervisor.dto.ConformacionCuadrillaRowRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

@Service
public class ConformacionCuadrillaMailService {
    private static final Logger logger = LoggerFactory.getLogger(ConformacionCuadrillaMailService.class);

    private final JavaMailSender mailSender;
    private final boolean enabled;
    private final String destinatario;
    private final String remitente;

    public ConformacionCuadrillaMailService(
            JavaMailSender mailSender,
            @Value("${app.cuadrilla.mail.enabled:false}") boolean enabled,
            @Value("${app.cuadrilla.mail.to:}") String destinatario,
            @Value("${app.cuadrilla.mail.from:}") String remitente) {
        this.mailSender = mailSender;
        this.enabled = enabled;
        this.destinatario = destinatario;
        this.remitente = remitente;
    }

    public void enviarDetalleCuadrillasNoConfirmadas(
            List<Map<String, Object>> cuadrillasDisponibles,
            List<ConformacionCuadrillaRowRequest> filasConfirmadas) {
        if (!enabled || isBlank(destinatario) || isBlank(remitente)) {
            logger.info(
                    "Correo cuadrillas omitido. enabled={}, toConfigured={}, fromConfigured={}",
                    enabled,
                    !isBlank(destinatario),
                    !isBlank(remitente)
            );
            return;
        }
        if (cuadrillasDisponibles == null || cuadrillasDisponibles.isEmpty()) {
            logger.info("Correo cuadrillas omitido. No hay cuadrillas disponibles para comparar.");
            return;
        }

        Set<String> confirmadas = new HashSet<>();
        String sucursal = null;
        LocalDate fecha = null;

        if (filasConfirmadas != null) {
            for (ConformacionCuadrillaRowRequest fila : filasConfirmadas) {
                if (fila == null) {
                    continue;
                }
                String grupo = normalize(fila.getGrupo());
                if (!grupo.isEmpty()) {
                    confirmadas.add(grupo);
                }
                if (isBlank(sucursal) && !isBlank(fila.getSucursal())) {
                    sucursal = fila.getSucursal().trim();
                }
                if (fecha == null && fila.getFecha() != null) {
                    fecha = fila.getFecha();
                }
            }
        }

        List<String> noConfirmadas = new ArrayList<>();
        for (Map<String, Object> row : cuadrillasDisponibles) {
            if (!esNoEliminada(row)) {
                continue;
            }
            String grupo = resolveString(row, "grupo", "nombre", "ruta", "cuadrilla");
            if (isBlank(grupo)) {
                continue;
            }
            String grupoKey = normalize(grupo);
            if (confirmadas.contains(grupoKey)) {
                continue;
            }
            String tecnico = resolveString(row, "nombrevendedor", "tecnico", "vendedor");
            String idTecnico = resolveString(row, "id_tecnico", "id_vendedor", "idvendedor");
            noConfirmadas.add(formatDetalle(grupo.trim(), tecnico, idTecnico));
        }

        String asunto = "Detalle de cuadrillas no confirmadas"
                + (fecha == null ? "" : " - " + fecha)
                + (isBlank(sucursal) ? "" : " - " + sucursal);

        StringBuilder body = new StringBuilder();
        body.append("Resumen de confirmacion de cuadrillas").append('\n');
        if (fecha != null) {
            body.append("Fecha: ").append(fecha).append('\n');
        }
        if (!isBlank(sucursal)) {
            body.append("Sucursal: ").append(sucursal).append('\n');
        }
        body.append("Total no confirmadas: ").append(noConfirmadas.size()).append('\n').append('\n');

        if (noConfirmadas.isEmpty()) {
            body.append("Todas las cuadrillas fueron confirmadas.");
        } else {
            body.append("Cuadrillas no confirmadas:").append('\n');
            for (String item : noConfirmadas) {
                body.append("- ").append(item).append('\n');
            }
        }

        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(remitente);
            message.setTo(destinatario);
            message.setSubject(asunto);
            message.setText(body.toString());
            mailSender.send(message);
            logger.info("Correo de cuadrillas no confirmadas enviado a {} con {} items.", destinatario, noConfirmadas.size());
        } catch (Exception ex) {
            logger.error("No se pudo enviar correo de cuadrillas no confirmadas.", ex);
        }
    }

    private String formatDetalle(String grupo, String tecnico, String idTecnico) {
        StringBuilder out = new StringBuilder(grupo);
        if (!isBlank(tecnico)) {
            out.append(" | Tecnico: ").append(tecnico.trim());
        }
        if (!isBlank(idTecnico)) {
            out.append(" | IdTecnico: ").append(idTecnico.trim());
        }
        return out.toString();
    }

    private String resolveString(Map<String, Object> row, String... keys) {
        if (row == null || keys == null) {
            return null;
        }
        for (String key : keys) {
            Object value = getCaseInsensitive(row, key);
            if (value == null) {
                continue;
            }
            String text = value.toString().trim();
            if (!text.isEmpty()) {
                return text;
            }
        }
        return null;
    }

    private Object getCaseInsensitive(Map<String, Object> row, String targetKey) {
        String normalizedTarget = normalize(targetKey);
        for (Map.Entry<String, Object> entry : row.entrySet()) {
            if (normalize(entry.getKey()).equals(normalizedTarget)) {
                return entry.getValue();
            }
        }
        return null;
    }

    private String normalize(String value) {
        if (value == null) {
            return "";
        }
        return value.replace("_", "").trim().toLowerCase(Locale.ROOT);
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private boolean esNoEliminada(Map<String, Object> row) {
        Object value = getCaseInsensitive(row, "e_eliminado");
        if (value == null) {
            value = getCaseInsensitive(row, "E_Eliminado");
        }
        if (value == null) {
            value = getCaseInsensitive(row, "eliminado");
        }
        if (value == null) {
            value = getCaseInsensitive(row, "Eliminado");
        }
        if (value == null) {
            return true;
        }
        if (value instanceof Boolean) {
            return !((Boolean) value);
        }
        if (value instanceof Number) {
            return ((Number) value).intValue() == 0;
        }
        String text = value.toString().trim().toLowerCase(Locale.ROOT);
        return "0".equals(text) || "false".equals(text) || "n".equals(text) || "no".equals(text);
    }
}
