package com.example.TigoStarSystem.supervisor.service;

import com.example.TigoStarSystem.common.ApiException;
import com.example.TigoStarSystem.supervisor.dto.ConformacionCuadrillaRowRequest;
import com.example.TigoStarSystem.supervisor.dto.ConformacionCuadrillaWebRequest;
import com.example.TigoStarSystem.supervisor.dto.ConformacionCuadrillaWebResponse;
import com.example.TigoStarSystem.supervisor.repository.ConformacionCuadrillaRepository;
import com.example.TigoStarSystem.supervisor.repository.ConformacionCuadrillaWebRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class ConformacionCuadrillaWebService {
    private static final Set<String> ESTADOS_VALIDOS =
            new HashSet<>(Arrays.asList("ACTIVO", "AUSENTE"));
    private static final Set<String> ACTIVIDADES_VALIDAS =
            new HashSet<>(Arrays.asList("TITULAR", "BACKUP"));

    private final ConformacionCuadrillaWebRepository repository;
    private final ConformacionCuadrillaRepository backofficeRepository;
    private final ConformacionCuadrillaMailService mailService;

    public ConformacionCuadrillaWebService(
            ConformacionCuadrillaWebRepository repository,
            ConformacionCuadrillaRepository backofficeRepository,
            ConformacionCuadrillaMailService mailService) {
        this.repository = repository;
        this.backofficeRepository = backofficeRepository;
        this.mailService = mailService;
    }

    public List<ConformacionCuadrillaWebResponse> listar(LocalDate fecha, String sucursal, Integer limite) {
        if (limite != null && limite < 0) {
            throw new ApiException(
                    HttpStatus.BAD_REQUEST,
                    "VALIDATION_ERROR",
                    "limite no puede ser negativo."
            );
        }
        return repository.listar(fecha, sucursal, limite);
    }

    public ConformacionCuadrillaWebResponse obtenerPorId(Long id) {
        validarId(id);
        ConformacionCuadrillaWebResponse row = repository.obtenerPorId(id);
        if (row == null) {
            throw new ApiException(
                    HttpStatus.NOT_FOUND,
                    "NOT_FOUND",
                    "Registro de conformacion cuadrilla web no encontrado."
            );
        }
        return row;
    }

    public ConformacionCuadrillaWebResponse crear(ConformacionCuadrillaWebRequest request) {
        validarFila(request);
        Long id = repository.crear(request);
        if (id == null) {
            throw new ApiException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "INSERT_FAILED",
                    "No se pudo registrar la conformacion cuadrilla web."
            );
        }
        List<ConformacionCuadrillaRowRequest> confirmadas = new ArrayList<>();
        confirmadas.add(mapToBackOfficeRow(request));
        mailService.enviarDetalleCuadrillasNoConfirmadas(
                backofficeRepository.listarGruposFiltroEdicion(),
                confirmadas
        );
        return obtenerPorId(id);
    }

    public ConformacionCuadrillaWebResponse actualizar(Long id, ConformacionCuadrillaWebRequest request) {
        validarId(id);
        validarFila(request);
        int affected = repository.actualizar(id, request);
        if (affected == 0) {
            throw new ApiException(
                    HttpStatus.NOT_FOUND,
                    "NOT_FOUND",
                    "Registro de conformacion cuadrilla web no encontrado."
            );
        }
        return obtenerPorId(id);
    }

    public int eliminar(Long id) {
        validarId(id);
        int affected = repository.eliminar(id);
        if (affected == 0) {
            throw new ApiException(
                    HttpStatus.NOT_FOUND,
                    "NOT_FOUND",
                    "Registro de conformacion cuadrilla web no encontrado."
            );
        }
        return affected;
    }

    public List<Map<String, Object>> listarTecnicos(String q, Integer limit) {
        return TecnicoSearchUtil.filterAndLimit(repository.listarTecnicos(), q, limit);
    }

    public List<Map<String, Object>> obtenerTecnicoDetalle(Integer idTecnico) {
        if (idTecnico == null || idTecnico <= 0) {
            throw new ApiException(
                    HttpStatus.BAD_REQUEST,
                    "VALIDATION_ERROR",
                    "idTecnico es requerido."
            );
        }
        return repository.obtenerTecnicoDetalle(idTecnico);
    }

    public List<Map<String, Object>> listarAuxiliares() {
        return repository.listarAuxiliares();
    }

    public List<Map<String, Object>> listarDigitadores() {
        return repository.listarDigitadores();
    }

    public List<Map<String, Object>> listarSupervisores() {
        return repository.listarSupervisores();
    }

    public List<Map<String, Object>> listarActividades() {
        return repository.listarActividades();
    }

    public List<Map<String, Object>> listarVehiculos(String filtro) {
        return repository.listarVehiculos(filtro);
    }

    public List<Map<String, Object>> listarSucursales() {
        return repository.listarSucursales();
    }

    private void validarId(Long id) {
        if (id == null || id <= 0) {
            throw new ApiException(
                    HttpStatus.BAD_REQUEST,
                    "VALIDATION_ERROR",
                    "id es requerido."
            );
        }
    }

    private void validarFila(ConformacionCuadrillaWebRequest fila) {
        if (fila == null) {
            throw new ApiException(
                    HttpStatus.BAD_REQUEST,
                    "VALIDATION_ERROR",
                    "Request requerido."
            );
        }

        normalizarCadenas(fila);

        List<String> faltantes = new ArrayList<>();
        if (fila.getEstado() == null) {
            faltantes.add("estado");
        }
        if (fila.getActividad() == null) {
            faltantes.add("actividad");
        }
        if (fila.getIdTecnico() == null) {
            faltantes.add("idTecnico");
        }
        if (fila.getIdUsuarioSupervisor() == null) {
            faltantes.add("idUsuarioSupervisor");
        }
        if (fila.getSucursal() == null) {
            faltantes.add("sucursal");
        }
        if (fila.getIdUsuarioRegistra() == null) {
            faltantes.add("idUsuarioRegistra");
        }
        if (!faltantes.isEmpty()) {
            throw new ApiException(
                    HttpStatus.BAD_REQUEST,
                    "VALIDATION_ERROR",
                    "Faltan campos requeridos: " + String.join(", ", faltantes)
            );
        }

        if (!ESTADOS_VALIDOS.contains(fila.getEstado())) {
            throw new ApiException(
                    HttpStatus.BAD_REQUEST,
                    "VALIDATION_ERROR",
                    "estado invalido. Valores permitidos: ACTIVO, INACTIVO."
            );
        }
        if (!ACTIVIDADES_VALIDAS.contains(fila.getActividad())) {
            throw new ApiException(
                    HttpStatus.BAD_REQUEST,
                    "VALIDATION_ERROR",
                    "actividad invalida. Valores permitidos: TITULAR, BACKUP."
            );
        }
        if (fila.getIdTecnicoAuxiliar() != null && fila.getIdTecnicoAuxiliar().equals(fila.getIdTecnico())) {
            throw new ApiException(
                    HttpStatus.BAD_REQUEST,
                    "VALIDATION_ERROR",
                    "idTecnicoAuxiliar no puede ser igual a idTecnico."
            );
        }
    }

    private void normalizarCadenas(ConformacionCuadrillaWebRequest fila) {
        fila.setEstado(normalizarEstado(fila.getEstado()));
        fila.setActividad(toUpperTrimOrNull(fila.getActividad()));
        fila.setCuentaSf(trimToNull(fila.getCuentaSf()));
        fila.setSalesforce(trimToNull(fila.getSalesforce()));
        fila.setHabilidad(trimToNull(fila.getHabilidad()));
        fila.setVehiculo(trimToNull(fila.getVehiculo()));
        fila.setGrupo(trimToNull(fila.getGrupo()));
        fila.setAlmacen(trimToNull(fila.getAlmacen()));
        fila.setGrupoDigitacion(trimToNull(fila.getGrupoDigitacion()));
        fila.setDigitador(trimToNull(fila.getDigitador()));
        fila.setTecnico(trimToNull(fila.getTecnico()));
        fila.setAuxiliar(trimToNull(fila.getAuxiliar()));
        fila.setSupervisorACargo(trimToNull(fila.getSupervisorACargo()));
        fila.setSucursal(trimToNull(fila.getSucursal()));
        fila.setObservacion(trimToNull(fila.getObservacion()));
    }

    private String normalizarEstado(String value) {
        String normalized = toUpperTrimOrNull(value);
        if ("INACTIVO".equals(normalized)) {
            return "AUSENTE";
        }
        return normalized;
    }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        return trimmed;
    }

    private String toUpperTrimOrNull(String value) {
        String trimmed = trimToNull(value);
        if (trimmed == null) {
            return null;
        }
        return trimmed.toUpperCase();
    }

    private ConformacionCuadrillaRowRequest mapToBackOfficeRow(ConformacionCuadrillaWebRequest in) {
        ConformacionCuadrillaRowRequest out = new ConformacionCuadrillaRowRequest();
        out.setFecha(in.getFecha());
        out.setEstado(in.getEstado());
        out.setActividad(in.getActividad());
        out.setIdTecnico(in.getIdTecnico());
        out.setCuentaSf(in.getCuentaSf());
        out.setSalesforce(in.getSalesforce());
        out.setHabilidad(in.getHabilidad());
        out.setVehiculo(in.getVehiculo());
        out.setGrupo(in.getGrupo());
        out.setAlmacen(in.getAlmacen());
        out.setGrupoDigitacion(in.getGrupoDigitacion());
        out.setIdUsuarioDigitador(in.getIdUsuarioDigitador());
        out.setDigitador(in.getDigitador());
        out.setTecnico(in.getTecnico());
        out.setIdTecnicoAuxiliar(in.getIdTecnicoAuxiliar());
        out.setAuxiliar(in.getAuxiliar());
        out.setIdUsuarioSupervisor(in.getIdUsuarioSupervisor());
        out.setSupervisorACargo(in.getSupervisorACargo());
        out.setSucursal(in.getSucursal());
        out.setObservacion(in.getObservacion());
        out.setIdUsuarioRegistra(in.getIdUsuarioRegistra());
        return out;
    }
}
